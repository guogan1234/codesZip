#include "treenode.h"
#include <QDebug>

TreeNode::TreeNode()
{
    m_value = 0;
    leftNode = nullptr;
    rightNode = nullptr;
}

TreeNode::TreeNode(int value)
{
    m_value = value;
    leftNode = nullptr;
    rightNode = nullptr;
}

int TreeNode::height(TreeNode *node)
{
    qDebug("TreeNode::height - %d\n",node->m_value);
    int ret = 0;
    if(node->leftNode == nullptr && node->rightNode == nullptr){
        return ret;
    }
    else {
        TreeNode* left = node->leftNode;
        int leftHeight = -1;
        if(left){
           leftHeight = height(node->leftNode);
           qDebug("leftHeight is %d, node value is %d\n",leftHeight,left->m_value);
        }
        TreeNode* right = node->rightNode;
        int rightHeight = -1;
        if(right){
            rightHeight = height(node->rightNode);
            qDebug("rightHeight is %d, node value is %d\n",rightHeight,right->m_value);
        }
        if(leftHeight >= rightHeight){
            return leftHeight + 1;
        }else {
            return rightHeight + 1;
        }
    }
}

void TreeNode::search(TreeNode *node)
{
    if(node){
        qDebug("value is %d\n",node->m_value);
        search(node->leftNode);
        search(node->rightNode);
    }else {
        return;
    }
}

void TreeNode::setLeftChild(TreeNode *parent, TreeNode *child)
{
    parent->leftNode = child;
}

void TreeNode::setRightChild(TreeNode *parent, TreeNode *child)
{
    parent->rightNode = child;
}
