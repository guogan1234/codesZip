#ifndef NODE_H
#define NODE_H

#include <QList>

class Node
{
public:
    Node();

    int height(Node* root);
    Node* getLeftChild();
    Node* getRightChild();
    void printByLevel(Node* node);

    int getValue();
private:
    Node* m_left;
    Node* m_right;
    int m_value;

    QList<Node*> list;
};

#endif // NODE_H
