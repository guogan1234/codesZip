#include "node.h"
#include <QDebug>

Node::Node()
{

}

int Node::height(Node *root)
{
    if(root == nullptr) return 0;
    Node* tempLeft = root->getLeftChild();
    int leftHeight = height(tempLeft);
    Node* tempRight = root->getRightChild();
    int rightHeight = height(tempRight);
    if(leftHeight > rightHeight){
        return leftHeight + 1;
    }else {
        return rightHeight + 1;
    }
}

Node *Node::getLeftChild()
{
    return m_left;
}

Node *Node::getRightChild()
{
    return m_right;
}

void Node::printByLevel(Node *node)
{
//    list.append(node->getValue());
    list.append(node);
    Node* left = nullptr;
    Node* right = nullptr;
    for(int i = 0; i < height(node); ++i){
        Node* temp = node->getLeftChild();
        if(temp){
            Node* removed = list.takeFirst();
            qDebug()<<"level,"<<i<<removed->getValue();
            list.append(temp);
        }
        temp = node->getRightChild();
        if(temp){
            list.takeFirst();
            list.append(temp);
        }
    }
}

int Node::getValue()
{
    return m_value;
}
