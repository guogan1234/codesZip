#include <QCoreApplication>
#include <QDebug>
#include "tester.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    tester test;
//    bool ret = false;
//    int arr_1[4] = {4,10,11,25};
//    int arr_2[4] = {4,10,1,2};
//    int len_1 = sizeof (arr_1)/sizeof (int);
//    ret = test.func(arr_1,len_1);
//    qDebug()<<"1:"<<ret;
//    len_1 = sizeof (arr_2)/sizeof (int);
//    ret = test.func(arr_2,len_1);
//    qDebug()<<"2:"<<ret;

//    //2
//    qDebug("---222---");
//    int arr_02[] = {4, 1, 9, 5, 9, 9, 7, 5, 3};
//    len_1 = sizeof (arr_02)/sizeof (int);
//    test.printNotRepeat(arr_02,len_1);

//    //3.
//    test.testMovieClass();

    //4.
    test.testNode();
    return a.exec();
}
