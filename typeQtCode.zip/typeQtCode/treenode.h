#ifndef TREENODE_H
#define TREENODE_H


class TreeNode
{
public:
    TreeNode();
    TreeNode(int value);

    int height(TreeNode* node);
    void search(TreeNode* node);

    void setLeftChild(TreeNode* parent,TreeNode* child);
    void setRightChild(TreeNode* parent,TreeNode* child);

    TreeNode* leftNode;
    TreeNode* rightNode;
    int m_value;
};

#endif // TREENODE_H
