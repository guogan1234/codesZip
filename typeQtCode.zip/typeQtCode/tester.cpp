#include "tester.h"
#include "movie.h"

tester::tester()
{

}

void tester::start()
{
//    public static bool func(int arr[], int n) {
//            for (int i = 0; i < n-1; i++) {
//                if (arr[i] <  arr[i+1])
//                {
//                    continue;
//                    if(i == n - 1){
//                        return true;
//                    }
//                }
////                    return true;
//                else
//                    return false;
//            }

//    }
}

bool tester::func(int *arr, int n)
{
    for (int i = 0; i < n-1; i++) {
        if (arr[i] <  arr[i+1])
        {
            continue;
            if(i == n - 1){
                return true;
            }
        }
//                    return true;
        else
            return false;
    }
    return false;
}

void tester::printNotRepeat(int *arr, int size)
{
    for(int i = 0;i <= size -1 ;i++){
        int temp = arr[i];

        bool bRepeat = false;
        for(int j = 0; j <= size - 1;j++){
            if(temp == arr[j] && i != j){
                bRepeat = true;
                break;
            }
        }

        if(bRepeat){
            continue;
        }else {
            qDebug("num: %d",temp);
        }
    }
}

void tester::testMovieClass()
{
    Movie movie("marvel");
    QString doctor("doctor");
    movie.addActor(doctor);
    QString stranger("stranger");
    movie.addActor(stranger);

    movie.printInfos();
}

void tester::testNode()
{
    TreeNode* root = initNode();
    int ret = root->height(root);
    qDebug("ret is %d\n",ret);
    root->search(root);
}

TreeNode *tester::initNode()
{
    //              (0)
    //             /   \
    //          (13)    (22)
    //          /  \     /  \
    //       (33) (28)(12)  (21)
    //       / \   /     \
    //   (55) (78)(89)   (111)
    TreeNode* root = nullptr;
    root = new TreeNode();
    TreeNode* left_node = new TreeNode(13);
    TreeNode* right_node = new TreeNode(22);
    root->setLeftChild(root,left_node);
    root->setRightChild(root,right_node);
    TreeNode* left_node_l_cn = new TreeNode(33);
    TreeNode* left_node_r_cn = new TreeNode(28);
    root->setLeftChild(left_node,left_node_l_cn);
    root->setRightChild(left_node,left_node_r_cn);
    TreeNode* left_node_l_cn_l_cn = new TreeNode(55);
    TreeNode* left_node_l_cn_r_cn = new TreeNode(78);
    root->setLeftChild(left_node_l_cn,left_node_l_cn_l_cn);
    root->setRightChild(left_node_l_cn,left_node_l_cn_r_cn);
    TreeNode* left_node_r_cn_l_cn = new TreeNode(89);
    root->setLeftChild(left_node_r_cn,left_node_r_cn_l_cn);

    TreeNode* right_node_l_cn = new TreeNode(12);
    TreeNode* right_node_r_cn = new TreeNode(21);
    root->setLeftChild(right_node,right_node_l_cn);
    root->setRightChild(right_node,right_node_r_cn);
    TreeNode* right_node_l_cn_r_cn = new TreeNode(111);
    root->setRightChild(right_node_l_cn,right_node_l_cn_r_cn);

    return root;
}

//void tester::func()
//{
//    for (int i = 0; i < n-1; i++) {
//        if (arr[i] <  arr[i+1])
//        {
//            continue;
//            if(i == n - 1){
//                return true;
//            }
//        }
////                    return true;
//        else
//            return false;
//    }
//}
