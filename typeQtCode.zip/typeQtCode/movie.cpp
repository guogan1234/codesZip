#include "movie.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <QDebug>

Movie::Movie()
{

}

Movie::Movie(const char *name)
{
    unsigned long long len = strlen(name);
    m_name = new char[len + 1];
    strcpy(m_name,name);
    m_name[len] = '\0';

    m_actors.clear();
}

Movie::~Movie()
{
    delete[] m_name;
    m_actors.clear();
}

void Movie::addActor(QString &actor)
{
    m_actors.append(actor);
}

void Movie::printInfos()
{
    qDebug()<<"movie name:"<<m_name;
    foreach (QString temp, m_actors) {
        qDebug()<<"actor:"<<temp;
    }
}
