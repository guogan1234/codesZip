#ifndef MOVIE_H
#define MOVIE_H

#include <QList>
#include <QString>

class Movie
{
public:
    Movie();
    explicit Movie(const char* name);
    ~Movie();

    void addActor(QString& actor);
    void printInfos();
private:
    char* m_name;
    QList<QString> m_actors;
};

#endif // MOVIE_H
