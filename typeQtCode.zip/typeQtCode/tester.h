#ifndef TESTER_H
#define TESTER_H

#include <QDebug>
#include "treenode.h"

class tester
{
public:
    tester();

    void start();
    bool func(int* arr,int size);

    void printNotRepeat(int* arr,int size);

    void testMovieClass();

    void testNode();
private:
    TreeNode* initNode();
};

#endif // TESTER_H
